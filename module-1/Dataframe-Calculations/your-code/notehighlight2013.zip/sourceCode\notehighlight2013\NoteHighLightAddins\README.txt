Based on project "NoteHighLight for the OneNote 2010 add code syntax highlighting package." (https://notehighlight.codeplex.com/).
